How to install Proxy Wars v1.1

1. Extract this zip.
2. Open the extracted folder.
3. Double-click INSTALL_FOR_THIS_PC.bat.
4. Close the Paradox launcher completely.
5. Open the launcher again.
6. Check All Installed Mods and add Proxy Wars to the playset.

What this version fixes:

- Fixes the tooltip saying "Your country is not allowed to send volunteers".
- Adds a country rule so countries are actually allowed to send volunteers.
- Adds a small national spirit called Proxy War Authorization.
- Reapplies the rule at game startup and when wars begin, so civil-war/proxy-war tags are more likely to work too.

What it still does:

- Removes the normal volunteer division cap by making the volunteer cap extremely high.
- Removes the 30-division requirement to send volunteers.
- Allows air volunteers up to the full available plane/base cap.

Important:

- This does not force the AI target to accept volunteers. If testing with console, use yesman if the AI refuses.
- This does not change map files, focus trees, countries, technology, factions, or nuclear systems.
- For multiplayer, every player should use the same zip and load order.
