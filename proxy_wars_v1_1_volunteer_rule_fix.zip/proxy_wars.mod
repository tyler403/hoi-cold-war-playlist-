version="1.1"
tags={
    "Gameplay"
}
name="Proxy Wars"
supported_version="1.19.*"
path="mod/proxy_wars"
