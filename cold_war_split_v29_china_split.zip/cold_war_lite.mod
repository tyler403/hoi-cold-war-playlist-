version="1.29"
tags={
    "Gameplay"
    "Historical"
}
name="Cold War Lite"
supported_version="1.19.*"
path="mod/cold_war_lite"
