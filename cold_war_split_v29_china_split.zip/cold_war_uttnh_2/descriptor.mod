version="1.29"
tags={
    "Gameplay"
    "Historical"
}
name="Cold War UTTNH_2"
supported_version="1.19.*"
dependencies={
    "UTTNH_2.0"
}
