How to install Cold War split mods v23

1. Extract this zip.
2. Open the extracted folder.
3. Double-click INSTALL_BOTH_MODS.bat.
4. Close the Paradox launcher completely.
5. Open the launcher again.
6. Check All Installed Mods.

You will now see two different mods:

- Cold War Lite
- Cold War UTTNH_2

Use only one of them in a playset:

- For vanilla HOI4, enable Cold War Lite.
- For UTTNH_2.0, enable UTTNH_2.0 and Cold War UTTNH_2.
- Do not enable Cold War Lite and Cold War UTTNH_2 at the same time.

What both mods do:

- Start the Cold War setup in 1945.
- Fix the map/faction/territory setup from the older Cold War Lite versions.
- Annex Poland and the Baltic states into the USSR.
- Keep the NATO and Warsaw Pact setup.
- Give USA/USSR buildings, facilities, and breakthrough progress.
- Leave the tech trees untouched at startup.

What is different:

- Cold War Lite no longer auto-researches the vanilla 1945 technology list.
- Cold War UTTNH_2 applies the SOV researched technology list from the user's cold war template save to both SOV and USA.
- Cold War UTTNH_2 gives USA and USSR special-project speed spirits.
- Cold War UTTNH_2 has a launcher dependency on UTTNH_2.0.

v13 adds a UTTNH_2 compatibility definition for the missing vanilla heavy_bombs tech used by Cold War Special Projects.
v14 adds the missing UTTNH_2 unlock OOB files for commando, deserti, and shock templates.
v15 adds compatibility tech aliases for UTTNH_2 AI strategy checks: special_forces_paratroopers and special_forces_marines.
v16 neutralizes Advanced Civil Wars' day-one on_war_relation_added hook inside Cold War UTTNH_2 so Italy does not explode into civil-war releasable wars on 1945.01.02.
v17 adds startup character safety for Sweden/Turkey 1945 event checks and replaces the bookmark/country picker text with historical Cold War descriptions.
v18 removes the risky TUR_nuri_demirag_prime_minister startup recruitment that triggers invalid Turkish prime-minister advisor checks, while keeping the safer TUR_nuri_demirag idea-token fix.
v19 adds UTTNH_2 playset overrides for Nuclear Destruction and Nuclear Deterrence parser errors seen in the 22:38 startup log.
v20 removes the automatic 1945 technology research from both split mods so saves can be prepared manually with console research.
v21 copies the 294 researched SOV technology IDs extracted from cold war template.hoi4 into Cold War UTTNH_2 and applies them to SOV and USA at startup.
v22 adds visible Cold War special-project research spirits to USA and USSR. USA gets Nuclear +30%, Air/Radar/Rockets +20%, Land +10%, Naval +10%. USSR gets Nuclear +27%, Air/Rockets +20%, Land +25%, Naval +10%.
v23 moves 5% of the USSR land special-project speed bonus into Air/Rockets, making USSR Air/Rockets +25% and Land +20%.

This replaces the v11 auto/forced tech-mode installer. There is no switching now because these are two separate mods.


V25 additions:
- AI majors receive hidden nuclear-ambition and Cold War-restraint ideas if controlled by AI.
- Scripted civil/proxy-war chains can occur from 1945 to 1970 only.
- Crisis events add Cold War flavour and temporary crisis posture, but do not force automatic World War Three.
