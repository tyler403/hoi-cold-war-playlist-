param()

$ErrorActionPreference = "Stop"

$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Documents = [Environment]::GetFolderPath("MyDocuments")
$HoiModDir = Join-Path $Documents "Paradox Interactive\Hearts of Iron IV\mod"

New-Item -ItemType Directory -Force -Path $HoiModDir | Out-Null

$Mods = @(
    @{
        Name = "Cold War Lite"
        Folder = "cold_war_lite"
        Descriptor = "cold_war_lite.mod"
    },
    @{
        Name = "Cold War UTTNH_2"
        Folder = "cold_war_uttnh_2"
        Descriptor = "cold_war_uttnh_2.mod"
    }
)

foreach ($Mod in $Mods) {
    $SourceFolder = Join-Path $SourceRoot $Mod.Folder
    $SourceDescriptor = Join-Path $SourceRoot $Mod.Descriptor
    $TargetFolder = Join-Path $HoiModDir $Mod.Folder
    $TargetDescriptor = Join-Path $HoiModDir $Mod.Descriptor

    if (-not (Test-Path -LiteralPath $SourceFolder)) {
        throw "Missing mod folder: $SourceFolder"
    }
    if (-not (Test-Path -LiteralPath $SourceDescriptor)) {
        throw "Missing descriptor: $SourceDescriptor"
    }

    if (Test-Path -LiteralPath $TargetFolder) {
        Remove-Item -LiteralPath $TargetFolder -Recurse -Force
    }

    Copy-Item -LiteralPath $SourceFolder -Destination $TargetFolder -Recurse -Force
    Copy-Item -LiteralPath $SourceDescriptor -Destination $TargetDescriptor -Force
    Write-Host "Installed $($Mod.Name)"
}

Write-Host ""
Write-Host "Done."
Write-Host "In the launcher, enable only ONE Cold War setup mod:"
Write-Host "- Vanilla playset: Cold War Lite"
Write-Host "- UTTNH_2 playset: UTTNH_2.0 + Cold War UTTNH_2"
Write-Host ""
Read-Host "Press Enter to close"
