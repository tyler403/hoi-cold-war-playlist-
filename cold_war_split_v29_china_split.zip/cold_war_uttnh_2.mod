version="1.29"
tags={
    "Gameplay"
    "Historical"
}
name="Cold War UTTNH_2"
supported_version="1.19.*"
path="mod/cold_war_uttnh_2"
dependencies={
    "UTTNH_2.0"
}
