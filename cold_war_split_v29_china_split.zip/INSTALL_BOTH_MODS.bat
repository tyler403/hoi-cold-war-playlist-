@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_both_mods.ps1"
if errorlevel 1 pause
