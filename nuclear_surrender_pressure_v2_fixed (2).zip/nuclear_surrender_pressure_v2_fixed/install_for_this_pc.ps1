param()

$ErrorActionPreference = "Stop"

$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Documents = [Environment]::GetFolderPath("MyDocuments")
$HoiModDir = Join-Path $Documents "Paradox Interactive\Hearts of Iron IV\mod"

New-Item -ItemType Directory -Force -Path $HoiModDir | Out-Null

$SourceFolder = Join-Path $SourceRoot "nuclear_surrender_pressure"
$SourceDescriptor = Join-Path $SourceRoot "nuclear_surrender_pressure.mod"
$TargetFolder = Join-Path $HoiModDir "nuclear_surrender_pressure"
$TargetDescriptor = Join-Path $HoiModDir "nuclear_surrender_pressure.mod"

if (-not (Test-Path -LiteralPath $SourceFolder)) {
    throw "Missing mod folder: $SourceFolder"
}
if (-not (Test-Path -LiteralPath $SourceDescriptor)) {
    throw "Missing descriptor: $SourceDescriptor"
}

if (Test-Path -LiteralPath $TargetFolder) {
    Remove-Item -LiteralPath $TargetFolder -Recurse -Force
}

Copy-Item -LiteralPath $SourceFolder -Destination $TargetFolder -Recurse -Force
Copy-Item -LiteralPath $SourceDescriptor -Destination $TargetDescriptor -Force

Write-Host "Installed Nuclear Surrender Pressure v1.1"
Write-Host "Close and reopen the Paradox launcher, then enable it in your playset."
Read-Host "Press Enter to close"
