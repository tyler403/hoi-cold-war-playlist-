How to install Nuclear Surrender Pressure v1.1

1. Extract this zip.
2. Open the extracted folder.
3. Double-click INSTALL_FOR_THIS_PC.bat.
4. Close the Paradox launcher completely.
5. Open the launcher again.
6. Enable Nuclear Surrender Pressure in your playset.

What this version does:

- Every nuclear strike applies surrender pressure to the country controlling the nuked state.
- The effect lasts 365 days.
- Further nukes upgrade or refresh the pressure.
- First nuke: surrender_limit -0.05.
- Second nuke: surrender_limit -0.10.
- Third and later nukes: capped at surrender_limit -0.15.
- Assuming a normal surrender threshold around 0.80, this means the cap is around 0.65 instead of making nukes force total capitulation by themselves.
- It does not change nuclear damage, missile behavior, SAM interception, map setup, or raid icons.

Why this is safer for MP:

- No white square icon.
- No instant surrender.
- No division wipe changes.
- No map devastation.
- Nukes help break a stalemate but should not auto-win a war.
