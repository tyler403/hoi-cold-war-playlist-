version="1.1"
tags={
    "Gameplay"
    "Military"
    "Balance"
}
name="Nuclear Surrender Pressure"
supported_version="1.19.*"
path="mod/nuclear_surrender_pressure"
