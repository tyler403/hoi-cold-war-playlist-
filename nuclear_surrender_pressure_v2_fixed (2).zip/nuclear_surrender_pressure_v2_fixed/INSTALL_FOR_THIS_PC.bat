@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_for_this_pc.ps1"
