How to install Nuclear Raid Warning and SAM Defense v1.5 / Defense Levels

1. Extract this zip.
2. Open the extracted folder.
3. Double-click INSTALL_FOR_THIS_PC.bat.
4. Close and reopen the Paradox/HOI4 launcher.
5. Add and enable Nuclear Raid Warning and SAM Defense in the same playset as your other mods.

Multiplayer:

- Every player must install this exact same zip.
- Every player must use the same HOI4 version, same DLC setup, same mods, and same load order.
- Put this mod below other mods that replace common/raids/nuclear_raids.txt if you want this mod's nuclear raid behavior to win.

What changed in v1.5:

- Added defense levels for missile nuclear raids.
- Level 0 now means no meaningful defense, so missile nukes have a 100% base chance to get through.
- Replaced the old single SAM defense modifier with three clearer defense components: radar coverage, AA coverage, and SAM/ABM network.
- Removed the old missile raid success modifiers for interception, radar, AA, and intel so the defense-level system is easier to understand and balance.
- Kept bomber nuclear raids mostly unchanged. The defense-level system applies to missile nuclear raids.
- Kept the radar warning event.
- Kept the SAM/interception notification events.
- Fixed zip packaging to use normal forward-slash folders, which is safer for sharing and extraction.

Defense level balance:

- Level 0: no radar, no AA, no SAM = about 100% through / 0% intercepted.
- Radar only = about 90% through / 10% intercepted.
- AA only = about 90% through / 10% intercepted.
- Radar + AA = about 80% through / 20% intercepted.
- SAM + radar or SAM + AA = about 60% through / 40% intercepted.
- SAM + radar + AA = about 50% through / 50% intercepted.

Limits:

- HOI4 raid scripting is probability-based, so 20 launches will not always produce the exact expected split.
- The radar warning still fires during the raid-result flow, not as a true player-reactable early warning.
- This mod replaces common/raids/nuclear_raids.txt, so it can conflict with other mods that also replace that file.
