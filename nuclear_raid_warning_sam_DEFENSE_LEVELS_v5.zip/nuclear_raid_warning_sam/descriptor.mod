version="1.5"
tags={
	"Gameplay"
	"Balance"
}
name="Nuclear Raid Warning and SAM Defense"
supported_version="1.19.*"
