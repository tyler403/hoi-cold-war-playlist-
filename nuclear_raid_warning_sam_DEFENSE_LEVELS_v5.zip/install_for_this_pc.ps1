$ErrorActionPreference = "Stop"

$modId = "nuclear_raid_warning_sam"
$modName = "Nuclear Raid Warning and SAM Defense"
$version = "1.5"

$sourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceModFolder = Join-Path $sourceRoot $modId
$sourceDescriptor = Join-Path $sourceModFolder "descriptor.mod"

if (-not (Test-Path -LiteralPath $sourceDescriptor)) {
    throw "Could not find $modId\descriptor.mod next to this installer. Extract the whole zip first, then run INSTALL_FOR_THIS_PC.bat again."
}

$rawDocumentDirs = New-Object System.Collections.Generic.List[string]

function Add-DocumentDir {
    param([string]$Path)
    if (-not [string]::IsNullOrWhiteSpace($Path)) {
        $rawDocumentDirs.Add($Path)
    }
}

Add-DocumentDir ([Environment]::GetFolderPath("MyDocuments"))

if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
    Add-DocumentDir (Join-Path $env:USERPROFILE "Documents")
    Add-DocumentDir (Join-Path $env:USERPROFILE "OneDrive\Documents")

    Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Filter "OneDrive*" -ErrorAction SilentlyContinue | ForEach-Object {
        Add-DocumentDir (Join-Path $_.FullName "Documents")
    }
}

foreach ($name in "ONEDRIVE", "OneDriveConsumer", "OneDriveCommercial") {
    $oneDrivePath = [Environment]::GetEnvironmentVariable($name)
    if (-not [string]::IsNullOrWhiteSpace($oneDrivePath)) {
        Add-DocumentDir (Join-Path $oneDrivePath "Documents")
    }
}

$hoi4Candidates = $rawDocumentDirs |
    Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
    ForEach-Object { Join-Path $_ "Paradox Interactive\Hearts of Iron IV" } |
    Sort-Object -Unique

$existingHoi4Dirs = $hoi4Candidates | Where-Object { Test-Path -LiteralPath $_ }

if ($existingHoi4Dirs.Count -gt 0) {
    $installTargets = $existingHoi4Dirs
} else {
    $fallbackDocuments = [Environment]::GetFolderPath("MyDocuments")
    if ([string]::IsNullOrWhiteSpace($fallbackDocuments)) {
        $fallbackDocuments = Join-Path $env:USERPROFILE "Documents"
    }
    $installTargets = @(Join-Path $fallbackDocuments "Paradox Interactive\Hearts of Iron IV")
}

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$descriptorText = @"
version="$version"
tags={
    "Gameplay"
    "Balance"
}
name="$modName"
supported_version="1.19.*"
"@

$installed = New-Object System.Collections.Generic.List[string]
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"

foreach ($hoi4Dir in $installTargets) {
    $hoi4ModDir = Join-Path $hoi4Dir "mod"
    New-Item -ItemType Directory -Path $hoi4ModDir -Force | Out-Null

    Get-ChildItem -LiteralPath $hoi4ModDir -Filter "$modId*.mod" -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne "$modId.mod" } |
        ForEach-Object {
            Rename-Item -LiteralPath $_.FullName -NewName ($_.Name + ".disabled_$stamp") -Force
        }

    $targetFolder = Join-Path $hoi4ModDir $modId
    if (Test-Path -LiteralPath $targetFolder) {
        $backupFolder = Join-Path $hoi4ModDir "$($modId)_backup_$stamp"
        Move-Item -LiteralPath $targetFolder -Destination $backupFolder -Force
        Write-Host "Backed up old folder:"
        Write-Host "  $backupFolder"
    }

    Copy-Item -LiteralPath $sourceModFolder -Destination $targetFolder -Recurse -Force

    $pathForHoi4 = $targetFolder.Replace("\", "/")
    $modFileText = @"
version="$version"
tags={
    "Gameplay"
    "Balance"
}
name="$modName"
supported_version="1.19.*"
path="$pathForHoi4"
"@

    [System.IO.File]::WriteAllText((Join-Path $hoi4ModDir "$modId.mod"), $modFileText, $utf8NoBom)
    [System.IO.File]::WriteAllText((Join-Path $targetFolder "descriptor.mod"), $descriptorText, $utf8NoBom)

    $installed.Add($hoi4ModDir)
}

$resultText = @()
$resultText += "$modName installed."
$resultText += ""
$resultText += "Installed into these HOI4 mod folders:"
foreach ($dir in $installed) {
    $resultText += "  $dir"
}
$resultText += ""
$resultText += "For multiplayer, every player must install this same zip and use the same playset/load order."
$resultText += "If the launcher was open, close it completely and reopen it."

$resultText | ForEach-Object { Write-Host $_ }

try {
    [System.IO.File]::WriteAllLines((Join-Path $sourceRoot "install_result.txt"), $resultText, $utf8NoBom)
} catch {
}
